from test import User, YoungLearner, Admin
from datetime import date


class Interface:

    def __init__(self):
        self.users_dict = dict()

    # ===================================== Validation ===================================== #

    @staticmethod
    def is_leap_year(year):
        """
        This function checks if the input year is a leap year.
        :param year: int
        :return: bool (True if leap year, False otherwise)
        """
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

    @staticmethod
    def is_valid_date_value(year, month, day):
        """
        This function checks if given datetime_str represents
        a valid date and time.
        :param datetime_str: a str representation of time and date
        :return: bool (True if datetime str exists, False otherwise)
        """

        # Convert to integers
        curr_year = date.today().year
        year_num = int(year)
        month_num = int(month)
        day_num = int(day)

        # Retrieve valid range values
        valid_years = range(1000, curr_year)
        valid_months = range(1, 13)
        if month_num not in valid_months \
                or year_num not in valid_years:
            return False

        # Days of a calendar month
        valid_days = []

        if month_num in [1, 3, 5, 7, 8, 10, 12]:
            # 31 days in Jan, Mar, May, Jul, Aug, Oct, Dec
            valid_days = range(1, 32)
        elif month_num in [4, 6, 9, 11]:
            # 30 days in Apr, Jun, Sep, Nov
            valid_days = range(1, 31)
        elif month_num == 2 and Interface.is_leap_year(year_num):
            # 29 days in Feb for leap year
            valid_days = range(1, 30)
        elif month_num == 2 and not Interface.is_leap_year(year_num):
            # 28 days in Feb for non-leap year
            valid_days = range(1, 29)

        return day_num in valid_days

    @staticmethod
    def ph_num_value(ph_num):
        if len(ph_num) > 10 or len(ph_num) < 9:
            print("Invalid phone number value!")
        else:
            return ph_num

    # ===================================== Menus ===================================== #

    def main_menu(self):
        """
        Prints the main menu options
        """

        print("\nPick your options:")
        print("\t1. Login")
        print("\t2. Register new account")
        print("\t3. Forgot password")

        while True:
            try:
                user_input = int(input("Please enter a menu option: "))
                if user_input in range(1, 3 + 1):

                    if user_input == 1:
                        self.login_menu()
                        break

                    elif user_input == 2:
                        self.registration_menu()
                        break

                    elif user_input == 3:
                        self.reset_password_menu()
                        break

                    else:
                        print("Please enter a valid integer from 1-3.")
            except:
                print("Invalid input, please enter an integer.")

    def login_menu(self):
        username = input("\nPlease enter your username: ")
        if username == "q":
            return self.main_menu()

        password = input("Please enter your password: ")
        if password == "q":
            return self.main_menu()

        if User.authenticate(self.users_dict, username, password):
            if isinstance(self.users_dict[username], Admin):
                return self.admin_interface()
            else:
                return self.learners_interface()
        else:
            print("Login attempt is unsuccessful")

    def registration_menu(self):

        # Register the user
        first_name = input("Please enter your first name: ")
        last_name = input("Please enter your last name: ")

        while True:
            try:
                year = int(input("Please enter your year of birth: "))
                month = int(input("Please enter your month of birth: "))
                day = int(input("Please enter your day of birth: "))

                if Interface.is_valid_date_value(year, month, day):
                    dob = date(year, month, day)
                    break
                else:
                    print("Not a valid input! Please try again!")

            except:
                print("Invalid format!")

        # First check whether the username is unique or not
        while True:
            username = input("Please enter a username: ")
            if username in self.users_dict:
                print("Username is already taken!")
            else:
                break

        password = input("Please enter a password: ")
        email = input("Please enter your email: ")

        while True:
            ph_num = input("Please enter your phone number (without any symbols): ")
            if Interface.ph_num_value(ph_num):
                break
            print("Please enter your phone number again!")

        User.register(self.users_dict, first_name, last_name, username, password, dob)
        # only learners are able to register
        self.learners_interface()

    def reset_password_menu(self):
        pass

    def admin_interface(self):
        """
        Prints the menu options for the admin user.
        """

        print("You have the following menu options:")
        print("\t1. Get user details")
        print("\t2. Get admin details")
        print("\t3. Log out")
        print("\t4. Shut down system")

        # print()
        #     print("Successfully logged in as admin.")
        #     while True:
        #         Interface.admin_menu()
        #         print()
        #         user_input = input("Please enter a menu option: ")
        #         if user_input == "1":
        #             # View other user profile
        #             profile_str = Admin.get_details_user(users_data)  # temp argument
        #             print("\n--- Other user details ---\n")
        #             print(profile_str)
        #             print("\n--- End of details ---\n")
        #         elif user_input == "2":
        #             # View own admin profile
        #             profile_str = Admin.get_details_admin(users_data)  # temp argument
        #             print("\n--- Admin details ---\n")
        #             print(profile_str)
        #             print("\n--- End of details ---\n")
        #         elif user_input == "3":
        #             # Log out
        #             print("Logging out...")
        #             break
        #         elif user_input == "4":
        #             # Shut down
        #             admin_username = input("Please enter your admin username: ")
        #             if admin_username == "q":
        #                 # Abort shutdown attempt
        #                 continue
        #             admin_password = input("Please enter your admin password: ")
        #             if admin_password == "q":
        #                 # Abort shutdown attempt
        #                 continue
        #             if Authenticate.authenticate_admin(admin_username, admin_password):
        #                 # Break out of the while loop
        #                 break
        #             else:
        #                 print("Incorrect admin credentials.")
        #             print("Shutting down game...")
        #             break
        #         else:
        #             print("You have not entered a valid menu option!",
        #                   "Please try again.")
        pass

    def learners_interface(self):
        """
        Prints the menu options for the user.
        """

        print("You have the following options:")
        print("\t1. View profile")
        print("\t2. Play game")
        print("\t3. Quizzes")
        print("\t4. Log out")
        print()

        # user_input = input("Please enter a menu option: ")
        # if user_input == "1":
        #     # View profile
        #     if username in user_dict:
        #         user = user_dict[username]
        #         user_details = user.get_details()
        #         print("User Details:")
        #         print(user_details)
        #     else:
        #         print("User not found!")
        #
        # elif user_input == "2":
        #     new_game1 = Game("Class", ["What is a class?", "Instance Variables", "Instantiation"])  # sample data
        #     new_game1.choose_game_difficulty()
        #     new_game1.choose_lm()
        #     new_game1.play_game()
        #     # Game.play_game(games_data)  # temp argument
        #
        # elif user_input == "3":
        #     # Display quizzes
        #     Quizzes.start_quiz()
        #
        # elif user_input == "4":
        #     # Log out
        #     print("Logging out...")
        #     break
        # else:
        #     print("You have not entered a valid menu option!",
        #           "Please try again.")
        #
        # print("Thank you for playing!")
        # print("Hope to see you again.")
        pass