"from week06_template"
from olduser import User
class Authenticate:

    @staticmethod
    def authenticate_admin(login_username, login_password):
        """
        Authenticates an admin account
        :param login_username: string
        :param login_password: string
        :return: bool
        """
        accounts = [["admin", "admin"],
                    ["admin2", "admin2"],
                    ["admin3", "admin3"]]
        result = False
        for idx in range(len(accounts)):
            # find admin username in accounts
            if accounts[idx][0] == login_username:
                # check if login_password matches stored password
                # if accounts[idx][1] == login_password:
                result = True
            break
        return result

    @staticmethod
    def authenticate_user(login_username, login_password, usernames, passwords):
        """
        Authenticates a user account.
        :param login_username: string
        :param login_password: string
        :param usernames: list of string
        :param passwords: list of string
        :return: bool
        """
        result = False
        for idx in range(len(usernames)):
            if usernames[idx] == login_username:
                if passwords[idx] == login_password:
                    result = True
                break
        return result

# admin_authenticator = Authenticate()
# admin_authenticator.authenticate_admin("admin", "admin")