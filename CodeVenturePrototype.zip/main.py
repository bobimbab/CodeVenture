from interface import Interface

# Create an instance of Interface
i = Interface()
i.main_menu()