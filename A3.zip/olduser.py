"from week07_template"
import os
from datetime import date


class User:

    def __init__(self, first_name, last_name, username, password,
                 dob, email, ph_num, role):
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.password = password
        self.dob = dob
        self.email = email
        self.ph_num = ph_num
        self.role = role
        # self.login_input = login_input

    @staticmethod
    def populate_user_data(user_data):
        """
        Read files from week06_patient.py and store into the HCMS data.
        :param user_data: a list of 9 lists: first_names, last_names, usernames,
                                             passwords, dob, email, ph_num,
                                             role, is_active
        :return: None
        """
        (first_names, last_names, usernames, passwords, dobs, emails, ph_nums, roles, is_actives) = user_data

        # By default, program will search if this file exists,
        # and will read contents in this file if so,
        # and populated into the system.
        updated_file_path = "./new_user_data.txt"

        # Otherwise, the file containing prepopulated data will be read
        # and populated into the system.
        prepopulated_file_path = "./user_data.txt"

        if os.path.exists(updated_file_path):
            read_file_path = updated_file_path
        elif os.path.exists(prepopulated_file_path):
            read_file_path = prepopulated_file_path
        else:
            print("The file user_data.txt does not exist!")
            return

        file = open(read_file_path, "r", encoding="utf8")
        lines = list(file)

        for line in lines:
            (first_name,
             last_name,
             username,
             password,
             dob,
             email,
             ph_num,
             role,
             is_active) = line.strip("\n").split(",")

            first_names.append(first_name)
            last_names.append(last_name)
            usernames.append(username)
            passwords.append(password)
            dobs.append(dob)
            emails.append(email)
            ph_nums.append(ph_num)
            roles.append(role)
            is_actives.append(is_active)

    @staticmethod
    def is_leap_year(year):
        """
        This function checks if the input year is a leap year.
        :param year: int
        :return: bool (True if leap year, False otherwise)
        """
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

    @staticmethod
    def is_valid_date_value(year, month, day):
        """
        This function checks if given datetime_str represents
        a valid date and time.
        :param datetime_str: a str representation of time and date
        :return: bool (True if datetime str exists, False otherwise)
        """

        # Convert to integers
        curr_year = date.today().year
        year_num = int(year)
        month_num = int(month)
        day_num = int(day)

        # Retrieve valid range values
        valid_years = range(1000, curr_year)
        valid_months = range(1, 13)
        if month_num not in valid_months \
                or year_num not in valid_years:
            return False

        # Days of a calendar month
        valid_days = []

        if month_num in [1, 3, 5, 7, 8, 10, 12]:
            # 31 days in Jan, Mar, May, Jul, Aug, Oct, Dec
            valid_days = range(1, 32)
        elif month_num in [4, 6, 9, 11]:
            # 30 days in Apr, Jun, Sep, Nov
            valid_days = range(1, 31)
        elif month_num == 2 and User.is_leap_year(year_num):
            # 29 days in Feb for leap year
            valid_days = range(1, 30)
        elif month_num == 2 and not User.is_leap_year(year_num):
            # 28 days in Feb for non-leap year
            valid_days = range(1, 29)

        return day_num in valid_days

    @staticmethod
    def ph_num_value(ph_num):
        if len(ph_num) > 10 or len(ph_num) < 9:
            print("Invalid phone number value!")
        else:
            return ph_num

    @staticmethod
    def register(first_name, last_name, dob, username, password, email, ph_num):
        first_name = input("Please enter your first name: ")
        last_name = input("Please enter your last name: ")

        dob = None
        validate_dob = False

        while not validate_dob:
            # User input to store for the patient's year of birth
            while True:
                try:
                    year = int(input("Please enter your year of birth: "))
                    month = int(input("Please enter your month of birth: "))
                    day = int(input("Please enter your day of birth: "))
                    break
                except:
                    print("Invalid format!")

            if User.is_valid_date_value(year, month, day):
                dob = date(year, month, day)
                validate_dob = True
            else:
                print("Not a valid input! Please try again!")
                continue

        username = input("Please enter a username: ")
        password = input("Please enter a password: ")
        email = input("Please enter your email: ")
        ph_verification = False
        while not ph_verification:
            ph_num = input("Please enter your phone number (without any symbols): ")
            if User.ph_num_value(ph_num):
                ph_verification = True
            else:
                print("Please enter your phone number again!")
                continue
        return first_name, last_name, dob, username, password, email, ph_num

    def get_details(self):

        # first_names = user_data[0]
        # last_names = user_data[1]
        # usernames = user_data[2]
        # passwords = user_data[3]
        # dobs = user_data[4]
        # emails = user_data[5]
        # ph_nums = user_data[6]
        # roles = user_data[7]
        # is_actives = user_data[8]
        #
        # return (f"User: {first_names[user_idx]} {last_names[user_idx]}\n"
        #         f"Username: {usernames[user_idx]}\n"
        #         f"Date of Birth: {dobs[user_idx]}\n"
        #         f"Email: {emails[user_idx]}\n"
        #         f"Phone Number: {ph_nums[user_idx]}\n"
        #         f"Role: {roles[user_idx]}\n"
        #         f"Is Active: {is_actives[user_idx]}")

        first_name = self.get_first_name()
        last_name = self.get_last_name()
        username = self.get_username()
        password = self.get_password()
        dob = self.get_dob()
        email = self.get_email()
        ph_num = self.get_ph_num()
        role = self.get_role()
        print(f"User: {first_name} {last_name}\n"
              f"Username: {username}\n"
              f"Password: {password}\n"
              f"Date of Birth: {dob}\n"
              f"Email: {email}\n"
              f"Phone Number: {ph_num}\n"
              f"Role: {role}\n")

    def reset_password(self):
        new_password = self.set_password()
        self.set_password(new_password)
        return new_password

    def __str__(self):
        return f"User: {self.first_name} {self.last_name}\nUsername: {self.username}\nDate of Birth: {self.dob}\nEmail: {self.email}\nPhone Number: {self.ph_num}\nRole: {self.role}"

    def get_first_name(self):
        return self.first_name

    def set_first_name(self, first_name):
        self.first_name = first_name

    def get_last_name(self):
        return self.last_name

    def set_last_name(self, last_name):
        self.last_name = last_name

    def get_username(self):
        return self.username

    def set_username(self, username):
        self.username = username

    def get_password(self):
        return self.password

    def set_password(self, password):
        self.password = password

    def get_dob(self):
        return self.dob

    def set_dob(self, dob):
        self.dob = dob

    def get_email(self):
        return self.email

    def set_email(self, email):
        self.email = email

    def get_ph_num(self):
        return self.ph_num

    def set_ph_num(self, ph_num):
        self.ph_num = ph_num

    def get_role(self):
        return self.role

    def set_role(self, role):
        self.role = role

    # testing
    # def change_password(self, new_pw):
    def change_password(self, new_pw):
        res = False
        new_pw = input("Please enter a new password: ")

        if new_pw == self.get_password():
            print("same password as old password")
            res = False

        else:
            self.set_password(new_pw)
            print("pw changed")
            res = True

        return res

    # def find_user_by_username(cls, username):
    #     for user in cls.user_list:
    #         if user.username == username:
    #             return user
    #     return None


if __name__ == "__main__":
    pass

    # user_list = [User('John', 'Doe', 'johndoe', 'pw', '2001-07-28', 'john@gmail.com', '0123456789', 'YL', 'active'),
    #              User('Sam', 'Loh', 'sammylol', 'qwerty', '1980-06-18', 'mrssam@hotmail.com', '0181111018', 'YL', 'active')]
    #
    # print(user_list[0].first_name)
    # print(user_list[0].last_name)
    # print(user_list[0].password)
    # print(user_list[0].role)
    # print(user_list[1].first_name)
    # print(user_list[1].password)

# To change the password, call the change_password method
#     user1.change_password("sadsad")

# user1 = User("John", "Doe", "johndoe", "password123",
#                  "1990-01-01", "john.doe@example.com", "123-456-7890",
#                  "YL", True)
# user1.register()
# user1.get_details()
