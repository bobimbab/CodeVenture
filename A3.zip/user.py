"from week07_template"
import os
from datetime import date
from authenticate import Authenticate

class User2:

    @staticmethod
    def register():
        first_name = input("Please enter your first name: ")
        last_name = input("Please enter your last name: ")

        dob = None
        validate_dob = False

        while not validate_dob:
            # User input to store for the patient's year of birth
            while True:
                try:
                    year = int(input("Please enter your year of birth: "))
                    month = int(input("Please enter your month of birth: "))
                    day = int(input("Please enter your day of birth: "))
                    break
                except:
                    print("Invalid format!")

            if User.is_valid_date_value(year, month, day):
                dob = date(year, month, day)
                validate_dob = True
            else:
                print("Not a valid input! Please try again!")
                continue

        username = input("Please enter a username: ")
        password = input("Please enter a password: ")
        email = input("Please enter your email: ")
        ph_verification = False
        while not ph_verification:
            ph_num = input("Please enter your phone number (without any symbols): ")
            if Interface.ph_num_value(ph_num):
                ph_verification = True
            else:
                print("Please enter your phone number again!")
                continue
        return

    # @staticmethod
    def read_user_details(self):

        user_list = []
        # first_names = data[0]
        # last_names = data[1]
        # usernames = data[2]
        # passwords = data[3]
        # dobs = data[4]
        # emails = data[5]
        # ph_nums = data[6]
        # roles = data[7]

        with open("user_data.txt", "r", encoding="utf8") as file:
            user_data = file.readlines()

            for line in user_data:
                (first_name,
                 last_name,
                 username,
                 password,
                 date_of_birth,
                 email,
                 ph_num,
                 role) = line.strip("\n").split(",")

                # first_names.append(first_name)
                # last_names.append(last_name)
                # usernames.append(username)
                # passwords.append(password)
                # dobs.append(date_of_birth)
                # emails.append(email)
                # ph_nums.append(ph_num)
                # roles.append(role)
                # if Authenticate.authenticate_user(login_username, login_password, usernames, passwords):
                # if username == logged_in_username and password == logged_in_password:
                print (f"First Name: {first_name}" + "\n"
                      + f"Last Name: {last_name}" + "\n"
                      + f"Username: {username}" + "\n"
                      + f"Date of birth: {date_of_birth}" + "\n"
                      + f"E-mail: {email}" + "\n"
                      + f"Phone number: {ph_num}" + "\n")
                # break

        # return user_data
        return user_list


class Interface2:

    @staticmethod
    def is_leap_year(year):
        """
        This function checks if the input year is a leap year.
        :param year: int
        :return: bool (True if leap year, False otherwise)
        """
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

    @staticmethod
    def is_valid_date_value(year, month, day):
        """
        This function checks if given datetime_str represents
        a valid date and time.
        :param datetime_str: a str representation of time and date
        :return: bool (True if datetime str exists, False otherwise)
        """

        # Convert to integers
        curr_year = date.today().year
        year_num = int(year)
        month_num = int(month)
        day_num = int(day)

        # Retrieve valid range values
        valid_years = range(1000, curr_year)
        valid_months = range(1, 13)
        if month_num not in valid_months \
                or year_num not in valid_years:
            return False

        # Days of a calendar month
        valid_days = []

        if month_num in [1, 3, 5, 7, 8, 10, 12]:
            # 31 days in Jan, Mar, May, Jul, Aug, Oct, Dec
            valid_days = range(1, 32)
        elif month_num in [4, 6, 9, 11]:
            # 30 days in Apr, Jun, Sep, Nov
            valid_days = range(1, 31)
        elif month_num == 2 and Interface2.is_leap_year(year_num):
            # 29 days in Feb for leap year
            valid_days = range(1, 30)
        elif month_num == 2 and not Interface2.is_leap_year(year_num):
            # 28 days in Feb for non-leap year
            valid_days = range(1, 29)

        return day_num in valid_days

    def register(self):
        # adds new user data into txt file upon requesting input
        with open("user_data.txt", "a") as file:
            first_name = input("Please enter your first name: ")
            last_name = input("Please enter your last name: ")
            dob = None
            validate_dob = False

            while not validate_dob:
                # User input to store for the patient's year of birth
                year = int(input("Please enter your year of birth: "))
                month = int(input("Please enter your month of birth: "))
                day = int(input("Please enter your day of birth: "))

                if Interface2.is_valid_date_value(year, month, day):
                    dob = str(date(year, month, day))
                    validate_dob = True
                else:
                    print("Not a valid input! Please try again!")
                    continue

            username = input("Please enter a username: ")
            password = input("Please enter a password: ")
            email = input("Please enter your email: ")
            ph_num = input("Please enter your phone number: ")
            role = input("Please choose a role YL / admin: ")
            file.write("\n" + first_name + ", " + last_name + ", " + dob + ", " + username + ", " + password + ", " + email + ", " + ph_num + ", " + role + ", " + "\n")

    def display_user_details(self):
        # view profile
        user = User2()
        user_data = user.read_user_details()
        for line in user_data:
            # print(line.strip())
            print(line.strip().split(","))


# interface = Interface2()

# Capture user details
# interface.capture_user_details()

# Display user details
# print("User Details:")
# interface.display_user_details()