class Quizzes:
    difficulty = ["Easy", "Medium", "Hard"]

    def __init__(self, ans_easy, ans_medium, ans_hard, easy_questions, medium_questions, hard_questions):
        self.ans_easy = ans_easy
        self.ans_medium = ans_medium
        self.ans_hard = ans_hard
        self.easy_questions = easy_questions
        self.medium_questions = medium_questions
        self.hard_questions = hard_questions
        self.player_difficulty = None

    def display_menu(self):
        print("-----Welcome to CODEVENTURE QUIZZES!-----")

    def choose_difficulty(self) -> None:
        """
        Prompt the user to select their difficulty
        :return:
        """
        while True:
            print("-------------------------------")
            print("Please choose your difficulty")
            print("1. Easy")
            print("2. Medium")
            print("3. Hard")
            try:
                user_input = int(input("Please select difficulty by their number. For example, '1' for Easy mode: "))
                if user_input > 3 or user_input < 1:
                    print("Please choose either Easy, Medium or Hard")
                elif user_input == "q":
                    print("You have quit the game!")
                    break
                else:
                    break
            except:
                print("Please enter a valid number")

        self.player_difficulty = Quizzes.difficulty[user_input - 1]
        print("You have choosen", self.player_difficulty)
        return self.player_difficulty

    def display_questions(self, questions, correct_answers):
        """
        Display the questions for the user
        :param questions:
        :param correct_answers:
        :return: None
        """
        for i in range(len(questions)):
            while True:
                print("QUESTION NUMBER", i + 1)
                print(questions[i])
                user_ans = input("Please input an answer: ")
                if self.validate_ans(user_ans, correct_answers, i):
                    print("Answer is correct!")
                    break
                else:
                    print("Answer is wrong!")

    def play_quiz(self) -> None:
        """
        start the quiz for the user
        :return: None
        """
        # display easy questions
        if self.player_difficulty == "Easy":
            self.display_questions(self.easy_questions, self.ans_easy)
        # display medium questions
        elif self.player_difficulty == "Medium":
            self.display_questions(self.medium_questions, self.ans_medium)
        # display hard questions
        elif self.player_difficulty == "Hard":
            self.display_questions(self.hard_questions, self.ans_hard)
        else:
            print("Please select your difficulty before you begin!")
        print("Congratulations on finishing the quiz! \n"
              "")

    def validate_ans(self, user_ans: str, answer: list, index) -> bool:
        # check if the questions are equal to the answer
        if user_ans == answer[index]:
            return True
        else:
            return False

    @staticmethod
    def start_quiz():
        # sample data
        quiz1_ans_easy = ["50", "3.0", "1"]
        quiz1_ans_medium = ["d", "b", "b"]
        quiz1_ans_hard = ["q", "60", "65"]
        quiz1_easy_questions = ["(2 + 3) * (13 - 3) = ?", "2 ** 3 / 2 - 4 + 3", "5 // 9 + 3 % 2"]
        quiz1_medium_questions = ["""
        Which operator is used for exponentiation in Python?\na) + \nb) * \nc) ^ \nd) ** \n""",
        """Which of the following data types is used to store a single character in 
        Python?\na) int\nb) str\nc) float\nd) bool\n""",
        """
        What is the primary purpose of a Python function?\n
        a) To store data \n
        b) To perform a specific task or operation \n
        c) To create a class \n
        d) To define a loop \n
        """]

        quiz1_hard_questions = ["To be IMPLEMENTED SOON. Please input 'q' to quit"]
        new_game1 = Quizzes(quiz1_ans_easy, quiz1_ans_medium, quiz1_ans_hard, quiz1_easy_questions,
                            quiz1_medium_questions, quiz1_hard_questions)
        new_game1.display_menu()
        new_game1.choose_difficulty()
        new_game1.play_quiz()


if __name__ == "__main__":
    # initialise a new quiz with the questions and answer banks provided by the database

    pass
