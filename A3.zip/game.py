class Game:
    difficulty = ["Easy","Medium","Hard"]


    def __init__(self, title:str, learning_modules: list):
        self.title = title
        self.game_difficulty = None
        self.learning_modules = learning_modules
        self.difficulty = None
        self.select_learning_module = None

    def play_game(self):
        """
        TO BE IMPLEMENTED
        * call Challenge class to display challenges
        * call Character_details class to display characters
        * pauses the game if needed
        * tracks and record progress and achievements if needed
        :return: None
        """
        print("Play game...")
        print("Coming soon!\n"
              "-------------------------------\n"
              "Preview of game content:\n \n"
              "Class is a blueprint or a template forC creating objects (instances). \n"
              "It defines a set of attributes (variables) and methods (functions) that the objects created from the "
              "class will have. \n"
              "Classes are fundamental to object-oriented programming (OOP) and are used to model real-world entities "
              "and their behaviors.\n"
              "\n"
              "Example: \n"
              "class Dog: \n"
              "     # Constructor method to initialize the object\n"
              "     def __init__(self, name, age):\n"
              "         self.name = name    # Attribute\n"
              "         self.age = age      # Attribute\n"
              "     # Method to make the dog bark\n"
              "     def bark(self):\n"
              "         print(self.name + 'says Woof!')\n"
              "End of preview\n")


    def pause_game(self):
        # pauses the game
        print("Pause game...")

    def choose_game_difficulty(self):
        """
        Prompt the user to select their difficulty for the game
        :return: None
        """
        while True:
            print("-------------------------------")
            print("Please choose your difficulty")
            print("1. Easy")
            print("2. Medium")
            print("3. Hard")
            try:
                user_input = int(input("Please select difficulty by their number. For example, '1' for Easy mode: "))
                if user_input > 3 or user_input < 1:
                    print("Please choose either Easy, Medium or Hard")
                else:
                    break
            except:
                print("Please enter a valid number")
        self.game_difficulty = Game.difficulty[user_input-1]
        print("You have choosen", self.game_difficulty)
        return self.game_difficulty

    def choose_lm(self):
        for idx, module in enumerate(self.learning_modules, start=1):
            print(f"{idx}. {module}")
        while True:
            try:
                user_input = int(input("Please select your learning module "))
                self.select_learning_module = self.learning_modules[user_input-1]
                break
            except:
                print("Invalid Input!")
        return self.select_learning_module


if __name__ == "__main__":
    pass