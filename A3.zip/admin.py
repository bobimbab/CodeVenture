from authenticate import Authenticate
# from olduser import User


class Admin(User):
    def __init__(self, first_name,last_name, admin_id,login_username, login_password):
        self.first_name = first_name
        self.last_name = last_name
        self.admin_id=admin_id
        super().__init__(login_username,login_password,role="AD")
        self.login_username=login_username
        self.login_password=login_password

    def get_details_user(self):
        return f"User ID: {self.user_id}, Name: {self.name}"

    def get_details_admin(self):
        return f"Admin ID: {self.admin_id}"


    def update(self):
        print("only admins can shut down")
        username = input("enter username")
        password = input("enter password")
        if super().authenticate_admin(username, password) is True:
            print("updating....")
        else:
            print("admin authentication failed")
        return

    def shut_down(self):
        print("only admins can shut down")
        username = input("enter username")
        password = input("enter password")
        if super().authenticate_admin(username,password) is True:
            print("system shutting down")
        else:
            print("admin authentication failed")
