from olduser import User


class YoungLearners(User):
    def __init__(self,first_name,last_name,grade,login_username,login_password):
        self.first_name = first_name
        self.last_name = last_name
        self.grade=grade
        super().__init__(login_username, login_password, role="YL")
        self.login_username = login_username
        self.login_password = login_password

    def get_details(self):
        return f"User ID: {self.user_id}, Name: {self.name},Grade:n{self.grade}"