# Referred to week6_main.py
import os
import re
from datetime import date
from test import User, user_dict
# from olduser import User
from user import User2
from admin import Admin
from authenticate import Authenticate
from game import Game
from quizzes import Quizzes



class Interface:

    def __init__(self):
        self.current_user = None

    @staticmethod
    def populate_user_data(user_data):
        """
        Read files from week06_patient.py and store into the HCMS data.
        :param user_data: a list of 9 lists: first_names, last_names, usernames,
                                             passwords, dob, email, ph_num,
                                             role, is_active
        :return: None
        """
        (first_names, last_names, usernames, passwords, dobs, emails, ph_nums, roles) = user_data

        # By default, program will search if this file exists,
        # and will read contents in this file if so,
        # and populated into the system.
        updated_file_path = "./new_user_data.txt"

        # Otherwise, the file containing prepopulated data will be read
        # and populated into the system.
        prepopulated_file_path = "./user_data.txt"

        if os.path.exists(updated_file_path):
            read_file_path = updated_file_path
        elif os.path.exists(prepopulated_file_path):
            read_file_path = prepopulated_file_path
        else:
            print("The file user_data.txt does not exist!")
            return

        file = open(read_file_path, "r", encoding="utf8")
        lines = list(file)

        for line in lines:
            (first_name, last_name, username, password, dob, email, ph_num, role) = line.strip("\n").split(",")

            first_names.append(first_name)
            last_names.append(last_name)
            usernames.append(username)
            passwords.append(password)
            dobs.append(dob)
            emails.append(email)
            ph_nums.append(ph_num)
            roles.append(role)


    def main_menu(self):
        """
        Prints the menu options.
        """
        print("Pick your options:")
        print("\t1. Login")
        print("\t2. Register new account")
        print("\t3. Forgot password")

    def learner_menu(self):
        """
        Prints the menu options for the user.
        """
        print("You have the following options:")
        print("\t1. View profile")
        print("\t2. Play game")
        print("\t3. Quizzes")
        print("\t4. Log out")

    @staticmethod
    def learner_main(users_data, logged_in_username):  # Add logged_in_username as an argument
        print()
        print("Successfully logged in as user.")
        while True:
            Interface.learner_menu()
            print()

            user_input = input("Please enter a menu option: ")
            if user_input == "1":
                # View profile
                found = False
                for line in users_data[2]:
                    if logged_in_username == line:
                        found = True
                        index = users_data[2].index(logged_in_username)
                        print("\n--- Your personal details ---\n")
                        print(f"First Name: {users_data[0][index]}\n"
                              f"Last Name: {users_data[1][index]}\n"
                              f"Username: {users_data[2][index]}\n"
                              f"Date of birth: {users_data[4][index]}\n"
                              f"E-mail: {users_data[5][index]}\n"
                              f"Phone number: {users_data[6][index]}\n")
                        print("\n--- End of details ---\n")
                        break

                if not found:
                    print("User not found in user_data.")

            elif user_input == "2":
                new_game1 = Game("Class", ["What is a class?", "Instance Variables", "Instantiation"])  # sample data
                new_game1.choose_game_difficulty()
                new_game1.choose_lm()
                new_game1.play_game()
                # Game.play_game(games_data)  # temp argument

            elif user_input == "3":
                # Display quizzes
                Quizzes.start_quiz()

            elif user_input == "4":
                # Log out
                print("Logging out...")
                break
            else:
                print("You have not entered a valid menu option!",
                      "Please try again.")
        print("Thank you for playing!")
        print("Hope to see you again.")


    def admin_menu(self):
        """
        Prints the menu options for the admin user.
        """
        print("You have the following menu options:")
        print("\t1. Get user details")
        print("\t2. Get admin details")
        print("\t3. Log out")
        print("\t4. Shut down system")

    @staticmethod
    def admin_main(users_data):  # temp argument
        print()
        print("Successfully logged in as admin.")
        while True:
            Interface.admin_menu()
            print()
            user_input = input("Please enter a menu option: ")
            if user_input == "1":
                # View other user profile
                profile_str = Admin.get_details_user(users_data)  # temp argument
                print("\n--- Other user details ---\n")
                print(profile_str)
                print("\n--- End of details ---\n")
            elif user_input == "2":
                # View own admin profile
                profile_str = Admin.get_details_admin(users_data)  # temp argument
                print("\n--- Admin details ---\n")
                print(profile_str)
                print("\n--- End of details ---\n")
            elif user_input == "3":
                # Log out
                print("Logging out...")
                break
            elif user_input == "4":
                # Shut down
                admin_username = input("Please enter your admin username: ")
                if admin_username == "q":
                    # Abort shutdown attempt
                    continue
                admin_password = input("Please enter your admin password: ")
                if admin_password == "q":
                    # Abort shutdown attempt
                    continue
                if Authenticate.authenticate_admin(admin_username, admin_password):
                    # Break out of the while loop
                    break
                else:
                    print("Incorrect admin credentials.")
                print("Shutting down game...")
                break
            else:
                print("You have not entered a valid menu option!",
                      "Please try again.")

    @staticmethod
    def is_leap_year(year):
        """
        This function checks if the input year is a leap year.
        :param year: int
        :return: bool (True if leap year, False otherwise)
        """
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

    @staticmethod
    def is_valid_date_value(year, month, day):
        """
        This function checks if given datetime_str represents
        a valid date and time.
        :param datetime_str: a str representation of time and date
        :return: bool (True if datetime str exists, False otherwise)
        """

        # Convert to integers
        curr_year = date.today().year
        year_num = int(year)
        month_num = int(month)
        day_num = int(day)

        # Retrieve valid range values
        valid_years = range(1000, curr_year)
        valid_months = range(1, 13)
        if month_num not in valid_months \
                or year_num not in valid_years:
            return False

        # Days of a calendar month
        valid_days = []

        if month_num in [1, 3, 5, 7, 8, 10, 12]:
            # 31 days in Jan, Mar, May, Jul, Aug, Oct, Dec
            valid_days = range(1, 32)
        elif month_num in [4, 6, 9, 11]:
            # 30 days in Apr, Jun, Sep, Nov
            valid_days = range(1, 31)
        elif month_num == 2 and Interface.is_leap_year(year_num):
            # 29 days in Feb for leap year
            valid_days = range(1, 30)
        elif month_num == 2 and not Interface.is_leap_year(year_num):
            # 28 days in Feb for non-leap year
            valid_days = range(1, 29)

        return day_num in valid_days

    @staticmethod
    def ph_num_value(ph_num):
        if len(ph_num) > 10 or len(ph_num) < 9:
            print("Invalid phone number value!")
        else:
            return ph_num


    def interface(self):
        """
        DO NOT MODIFY THIS FUNCTION DEFINITION.
        This function handles all program logic related to the main menu.
        :return: None
        """

        first_names = []
        last_names = []
        usernames = []
        passwords = []
        dobs = []
        emails = []
        ph_nums = []
        roles = []
        users_data = [first_names,
                      last_names,
                      usernames,
                      passwords,
                      dobs,
                      emails,
                      ph_nums,
                      roles]
        games_data = []
        curr_date = date.today()

        print("Welcome to CodeVenture!")
        print()

        # Populate patients data from txt file
        Interface.populate_user_data(users_data)

        while True:
            # Print the main menu
            Interface.main_menu(self)
            print()
            menu_input = input("Please enter a menu option: ")

            if menu_input == "1":
                print()
                login_username = input("Please enter your username: ")
                if login_username == "q":
                    continue
                login_password = input("Please enter your password: ")
                if login_password == "q":
                    continue
                if User.login(user_dict, login_username, login_password):
                    print("Login successful!")
                # if Authenticate.authenticate_admin(login_username, login_password):
                #     # Successfully logged in as admin
                #     Interface.admin_main(users_data)
                # elif Authenticate.authenticate_user(login_username,
                #                                     login_password,
                #                                     usernames,
                #                                     passwords):
                #     logged_in_username = login_username
                #     Interface.learner_main(users_data, logged_in_username)
                else:
                    print("Login attempt is unsuccessful.")

            elif menu_input == "2":
                # Register new user
                first_name = input("Please enter your first name: ")
                last_name = input("Please enter your last name: ")

                dob = None
                validate_dob = False

                while not validate_dob:
                    # User input to store for the patient's year of birth
                    while True:
                        try:
                            year = int(input("Please enter your year of birth: "))
                            month = int(input("Please enter your month of birth: "))
                            day = int(input("Please enter your day of birth: "))
                            break
                        except:
                            print("Invalid format!")

                    if Interface.is_valid_date_value(year, month, day):
                        dob = date(year, month, day)
                        validate_dob = True
                    else:
                        print("Not a valid input! Please try again!")
                        continue

                username = input("Please enter a username: ")
                password = input("Please enter a password: ")
                email = input("Please enter your email: ")
                ph_verification = False
                while not ph_verification:
                    ph_num = input("Please enter your phone number (without any symbols): ")
                    if Interface.ph_num_value(ph_num):
                        ph_verification = True
                    else:
                        print("Please enter your phone number again!")
                        continue
                role = "YL"
                # first_name = ""
                # last_name = ""
                # dob = None
                # username = ""
                # password = ""
                # email = ""
                # ph_num = ""
                #
                # User.register(first_name, last_name, dob, username, password, email, ph_num)

                # first_names.append(first_name)
                # last_names.append(last_name)
                # dobs.append(dob)
                # usernames.append(username)
                # passwords.append(password)
                # emails.append(email)
                # ph_nums.append(ph_num)
                User.register(user_dict, first_name, last_name, username, password, dob, role, email, ph_num)


                # Interface.populate_user_data(users_data)
                print(user_dict)
                print(f"User's name is {first_name} {last_name}\n"
                      f"User's date of birth is {dob}\n"
                      f"User's username is {username}\n"
                      f"Registration attempt is successful.")

            elif menu_input == "3":
                # Forgot password
                print()
                user_input = input("Enter username: ")
                ph_verification = False
                while not ph_verification:
                    ph_no = input("Please enter your phone number for verification: ")
                    if Interface.ph_num_value(ph_no):
                        print("Your phone number has been verified.")
                        with open("user_data.txt", "r") as file:
                            for line in file:
                                data = line.strip().split(",")
                                if data[2] == user_input:
                                    print("\nYour Password is", data[3])
                                    break
                                else:
                                    print("user not found")
                                    continue
                        ph_verification = True
                    else:
                        print("Please enter your phone number again!")
                        continue

            # def get_pass():

            elif menu_input == "q":
                print("Shutting down CodeVenture...")
                break


if __name__ == "__main__":
    i = Interface()
    i.interface()

