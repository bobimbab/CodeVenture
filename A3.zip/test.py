from datetime import date


class User:

    def __init__(self, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str | None = None, ph_num: str | None = None) -> None:
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.password = password
        self.dob = dob
        self.email = email
        self.ph_num = ph_num

    @staticmethod
    def register(users_dict: dict, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str | None = None, ph_num: str | None = None):
        """
        Registers the user according to the parameters provided.
        Returns true if the registration is successful, and false if otherwise

        Arguments:
        - first_name: Something something, insert into dict

        Returns:
        - bool: A boolean that represents whether the registration was successful or not.
        """
        if username not in users_dict:
            users_dict[username] = User(first_name, last_name, username, password, dob, email, ph_num)
            return True
        return False

    @staticmethod
    def authenticate(users_dict: dict, username: str, password: str) -> bool:
        """
        Authenticates the user based on their username and password

        Arguments:
        - users dict:
        - username: A string that represents the username of the user
        - password: A string that represents the password of the user

        Returns:
        - bool: A boolean that states whether the user has been authenticated successfully
        """
        if username not in users_dict or users_dict[username].password != password:
            return False
        return True

    def get_details(self) -> str:
        """
        Retrieves all user details in a formatted string.

        Returns:
        - str: A formatted string containing user details.
        """
        return f"User: {self.first_name} {self.last_name}\n" \
               f"Username: {self.username}\n" \
               f"Date of Birth: {self.dob}\n" \
               f"Email: {self.email}\n" \
               f"Phone Number: {self.ph_num}\n"


class YoungLearner(User):

    def __init__(self, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str, ph_num: str):
        super().__init__(first_name, last_name, username, password, dob, email, ph_num)
        self.grade = None

    @staticmethod
    def register(users_dict: dict, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str, ph_num: str) -> dict:
        users_dict[username] = YoungLearner(first_name, last_name, username, password, dob, email, ph_num)
        return users_dict

    def get_details(self) -> str:
        return f"User: {self.first_name} {self.last_name}\n" \
               f"Username: {self.username}\n" \
               f"Date of Birth: {self.dob}\n" \
               f"Email: {self.email}\n" \
               f"Phone Number: {self.ph_num}\n" \
               f"Grade: {self.grade}\n"


class Admin(User):
    def __init__(self, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str, ph_num: str):
        super().__init__(first_name, last_name, username, password, dob, email, ph_num)

    @staticmethod
    def register(users_dict: dict, first_name: str, last_name: str, username: str, password: str, dob: date,
                 email: str, ph_num: str) -> dict:
        users_dict[username] = Admin(first_name, last_name, username, password, dob, email, ph_num)
        return users_dict

    def get_details(self) -> str:
        return f"User: {self.first_name} {self.last_name}\n" \
               f"Username: {self.username}\n" \
               f"Date of Birth: {self.dob}\n" \
               f"Email: {self.email}\n" \
               f"Phone Number: {self.ph_num}\n"
                # f"Grade: {self.grade}\n"
